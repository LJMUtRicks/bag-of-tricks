# eDNA Nanopore Sequencing — Bookdown Tutorial

## Pre-install
```r
install.packages(c("bookdown","rmarkdown","knitr","kableExtra","webexercises"))
```

## Build
```r
bookdown::render_book("index.Rmd", "bookdown::gitbook")
```
Output in `docs/` for GitHub Pages.
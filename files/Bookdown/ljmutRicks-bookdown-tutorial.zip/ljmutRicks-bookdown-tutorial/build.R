if (!requireNamespace("bookdown", quietly = TRUE)) {
  install.packages("bookdown", repos = "https://cloud.r-project.org")
}
bookdown::render_book("index.Rmd", "bookdown::gitbook")